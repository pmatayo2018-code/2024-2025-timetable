
# Project Description

This project demonstrates how to create and style HTML tables for presenting structured data in a clear and organized way. It includes examples of table headers, row and column spanning, borders, and basic styling techniques. The project is designed to help beginners understand the role of tables in web development and how to make them both functional and visually appealing.


# Accessibility Considerations

* Used semantic HTML tags like table, ***thead***, ***tbody***, and ***th***  to improve screen reader compatibility.

* Added table captions to describe the content and purpose of each table.

* Included scope attributes (scope="col" and scope="row") to help screen readers associate headers with the right cells.

* Ensured good color contrast for readability.
